import {Component} from "react";
import { Link } from "react-router-dom";
class Catalog extends Component{
    constructor(props)
    {
        super(props);
        this.state={travelName:"Yamuna",luxuryType:"Non Ac",price:"400"};
    }
    travelName="Yamuna";
    luxuryType="Non Ac";
    price="400"
    render(){
        return(<div>
            <center>
                <form>
                    <h3>Bus Catalogue</h3><br></br>
                    <label><b>Travel's Name : </b></label>
                    <select size="1" name="travelName" defaultValue={this.state.travelName}>
                        <option value="Ganga">Ganga</option>
                        <option value="Yamuna">Yamuna</option>
                        <option value="Lakshmi">Lakshmi</option>
                        <option value="Krishna">Krishna</option>
                        </select><br></br><br></br>
                    <label><b>Luxury Type : </b></label>
                    <select size="1" name="luxuruType" defaultValue={this.state.luxuryType}>
                        <option value="Ac Sleeper">Ac Sleeper</option>
                        <option value="Non Ac Sleeper">Non Ac Sleeper</option>
                        <option value="Ac Seater"> Ac Seater</option>
                        <option value="Non Ac Seater">Non Ac Seater</option>
                    </select><br></br><br></br>  
                    <label><b>Price : </b></label>
                    <select size="1" name="luxuruType" defaultValue={this.state.price}>
                        <option value="800">Ac Sl - Rup.800</option>
                        <option value="450">Non-Ac Sl - Rup.450</option>
                        <option value="550">Ac Se - Rup.550</option>
                        <option value="300">Non-Ac Se - Rup.300</option>
                    </select><br></br><br></br> 
                    <Link to="/BookingDetails">
              <button type="button">
                <h3>Next</h3>
            
          </button></Link>
                    
                </form>
            </center>
        </div>
        )
    }
}
export default Catalog;
